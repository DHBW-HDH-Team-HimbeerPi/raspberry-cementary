raspi
=====

This module provides some helper functions to use with the Raspberry Pi and the RPi.GPIO.

Description
-----------

**Description**

This module provides some helper functions to use with the Raspberry Pi and the RPi.GPIO.

When I can I will add more.

If anyone wishes to contribute with new code or corrections/suggestions, feel free.

Installation
------------

**Installation**

.. code:: bash

    $ pip install raspi

Resources and contributing
--------------------------

**Resources**

* `Repository <https://github.com/jcrmatos/raspi>`_

**Contributing**

1. Fork the `repository`_ on GitHub.
2. Make a branch of master and commit your changes to it.
3. Ensure that your name is added to the end of the AUTHORS.rst file using the format:
   ``Name <email@domain.com>``
4. Submit a Pull Request to the master branch on GitHub.

.. _repository: https://github.com/jcrmatos/raspi

Copyright 2009-2015 Joao Carlos Roseta Matos. Licensed under the GNU General Public License v2 or later (GPLv2+).
